

def printVal():
	return help('modules')