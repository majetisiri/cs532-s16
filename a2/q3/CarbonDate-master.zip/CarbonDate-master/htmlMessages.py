
def printHTMLmessage(): 
   return """<html>
                 <h1>...Please Wait</h1>
          </html>"""